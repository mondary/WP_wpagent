# Changelog

All notable changes to this plugin will be documented in this file.

The format is based on Keep a Changelog, and this project adheres to Semantic Versioning.

## 0.1.1 - 2025-12-18
- Admin: new minimal full-white UI; CSS/JS extracted into `assets/admin.css` and `assets/admin.js`.
- PWA + capture page: switched to a minimal white theme.

## 0.1.0 - 2025-12-18
- Initial release.

