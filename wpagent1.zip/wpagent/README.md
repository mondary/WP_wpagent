# WPA Agent (wpagent)

Objectif: capturer rapidement des "sujets" depuis mobile (une inbox), puis les convertir ensuite en brouillons via IA.

## Installation

1. Copie le dossier `wpagent/` dans `wp-content/plugins/wpagent/`
2. Active le plugin **WPA Agent** dans l’admin WordPress

## Où voir la liste

- Menu admin: **WPA Agent** → **Sujets**

## Capture depuis mobile

Le plugin expose un endpoint REST protégé par un token (généré à l’activation).

- Admin: **WPA Agent** → copie le token et les URLs
- Ajouter un sujet (GET/POST): `/wp-json/wpagent/v1/inbox`
- Page mobile simple (HTML): `/wp-json/wpagent/v1/capture?token=...`
- PWA installable (Android): `/wp-json/wpagent/v1/pwa/app`

### Exemple GET (rapide)

`https://ton-site.tld/wp-json/wpagent/v1/inbox?token=TON_TOKEN&text=Une%20id%C3%A9e`

### Exemple iOS Raccourcis (recommandé)

- Action **Obtenir le contenu de l’URL**
  - URL: `https://ton-site.tld/wp-json/wpagent/v1/inbox`
  - Méthode: `POST`
  - Champs: `token`, `text` (optionnels: `url`, `source_title`)

## Android (Partager → WPA Agent)

1. Ouvre `https://ton-site.tld/wp-json/wpagent/v1/pwa/app` dans Chrome
2. Menu ⋮ → **Ajouter à l’écran d’accueil**
3. Ouvre WPA Agent une fois, colle le token (depuis l’admin), clique **Enregistrer**
4. Depuis Chrome / une app compatible: **Partager** → **WPA Agent** → ajout automatique à l’inbox

## Inbox → Draft WordPress (IA)

Dans l’admin **WPA Agent**, configure:

- Provider: `openrouter` ou `gemini`
- La clé API et le modèle

Puis, dans la section **Inbox → Générer un draft**, clique **Générer un draft**:

- Un post WordPress standard est créé en `draft`
- Tu relis/modifies puis tu publies via WordPress normalement
