<?php

if (!defined('ABSPATH')) {
	exit;
}

final class WPAgent_Admin {
	public static function init(): void {
		add_action('admin_menu', [self::class, 'admin_menu']);
		add_action('admin_post_wpagent_regenerate_token', [self::class, 'handle_regenerate_token']);
		add_action('admin_post_wpagent_save_settings', [self::class, 'handle_save_settings']);
		add_action('admin_post_wpagent_generate_draft', [self::class, 'handle_generate_draft']);
	}

	public static function admin_menu(): void {
		add_menu_page(
			'WPA Agent',
			'WPA Agent',
			'manage_options',
			'wpagent',
			[self::class, 'render_page'],
			'dashicons-lightbulb',
			58
		);

		add_submenu_page(
			'wpagent',
			'Sujets',
			'Sujets',
			'edit_posts',
			'edit.php?post_type=' . WPAgent_Post_Type::POST_TYPE
		);
	}

	public static function handle_regenerate_token(): void {
		if (!current_user_can('manage_options')) {
			wp_die('Forbidden', 403);
		}
		check_admin_referer('wpagent_regenerate_token');

		WPAgent_Settings::regenerate_token();
		wp_safe_redirect(admin_url('admin.php?page=wpagent'));
		exit;
	}

	public static function handle_save_settings(): void {
		if (!current_user_can('manage_options')) {
			wp_die('Forbidden', 403);
		}
		check_admin_referer('wpagent_save_settings');

		$provider = isset($_POST['provider']) ? sanitize_text_field((string) $_POST['provider']) : 'openrouter';
		if (!in_array($provider, ['openrouter', 'gemini'], true)) {
			$provider = 'openrouter';
		}
		update_option(WPAgent_Settings::OPTION_PROVIDER, $provider, false);

		$openrouter_key = isset($_POST['openrouter_api_key']) ? sanitize_text_field((string) $_POST['openrouter_api_key']) : '';
		update_option(WPAgent_Settings::OPTION_OPENROUTER_API_KEY, $openrouter_key, false);

		$openrouter_model = isset($_POST['openrouter_model']) ? sanitize_text_field((string) $_POST['openrouter_model']) : '';
		update_option(WPAgent_Settings::OPTION_OPENROUTER_MODEL, $openrouter_model, false);

		$gemini_key = isset($_POST['gemini_api_key']) ? sanitize_text_field((string) $_POST['gemini_api_key']) : '';
		update_option(WPAgent_Settings::OPTION_GEMINI_API_KEY, $gemini_key, false);

		$gemini_model = isset($_POST['gemini_model']) ? sanitize_text_field((string) $_POST['gemini_model']) : '';
		update_option(WPAgent_Settings::OPTION_GEMINI_MODEL, $gemini_model, false);

		$system_prompt = isset($_POST['system_prompt']) ? wp_kses_post((string) $_POST['system_prompt']) : '';
		update_option(WPAgent_Settings::OPTION_SYSTEM_PROMPT, $system_prompt, false);

		wp_safe_redirect(admin_url('admin.php?page=wpagent&updated=1'));
		exit;
	}

	public static function handle_generate_draft(): void {
		if (!current_user_can('edit_posts')) {
			wp_die('Forbidden', 403);
		}
		check_admin_referer('wpagent_generate_draft');

		$topic_id = isset($_POST['topic_id']) ? (int) $_POST['topic_id'] : 0;
		if ($topic_id <= 0) {
			wp_safe_redirect(admin_url('admin.php?page=wpagent&error=missing_topic'));
			exit;
		}

		$result = WPAgent_AI::generate_draft_from_topic($topic_id);
		if (is_wp_error($result)) {
			$msg = rawurlencode($result->get_error_message());
			wp_safe_redirect(admin_url('admin.php?page=wpagent&error=' . $msg));
			exit;
		}

		$draft_id = (int) $result;
		wp_safe_redirect(get_edit_post_link($draft_id, 'url'));
		exit;
	}

	public static function render_page(): void {
		if (!current_user_can('manage_options')) {
			wp_die('Forbidden', 403);
		}

		$token = WPAgent_Settings::get_token();
		$inbox_url = site_url('/wp-json/wpagent/v1/inbox');
		$capture_url = site_url('/wp-json/wpagent/v1/capture?token=' . rawurlencode($token));
		$topics_url = site_url('/wp-json/wpagent/v1/topics?token=' . rawurlencode($token));
		$pwa_url = site_url('/wp-json/wpagent/v1/pwa/app');

		$provider = WPAgent_Settings::get_provider();
		$openrouter_model = WPAgent_Settings::get_openrouter_model();
		$gemini_model = WPAgent_Settings::get_gemini_model();
		$system_prompt = WPAgent_Settings::get_system_prompt();
		$openrouter_key = (string) get_option(WPAgent_Settings::OPTION_OPENROUTER_API_KEY, '');
		$gemini_key = (string) get_option(WPAgent_Settings::OPTION_GEMINI_API_KEY, '');

		echo '<div class="wrap">';
		echo '<h1>WPA Agent</h1>';
		echo '<p>Objectif: capturer rapidement des sujets depuis ton téléphone, puis les convertir ensuite en brouillons via IA.</p>';

		if (isset($_GET['updated'])) {
			echo '<div class="notice notice-success"><p>Réglages enregistrés.</p></div>';
		}
		if (isset($_GET['error'])) {
			echo '<div class="notice notice-error"><p>' . esc_html((string) $_GET['error']) . '</p></div>';
		}

		echo '<h2>Token</h2>';
		echo '<p><code>' . esc_html($token) . '</code></p>';
		echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
		wp_nonce_field('wpagent_regenerate_token');
		echo '<input type="hidden" name="action" value="wpagent_regenerate_token"/>';
		submit_button('Régénérer le token', 'secondary', 'submit', false);
		echo '</form>';

		echo '<h2>Endpoints</h2>';
		echo '<ul>';
		echo '<li>Ajouter (GET/POST): <code>' . esc_html($inbox_url) . '</code></li>';
		echo '<li>Liste (GET): <code>' . esc_html($topics_url) . '</code></li>';
		echo '<li>Page capture (mobile): <code>' . esc_html($capture_url) . '</code></li>';
		echo '<li>PWA Android (installable): <code>' . esc_html($pwa_url) . '</code></li>';
		echo '</ul>';

		echo '<h2>PWA (Android “Partager → WPA Agent”)</h2>';
		echo '<p><a class="button button-primary" href="' . esc_url($pwa_url) . '" target="_blank" rel="noreferrer noopener">Ouvrir la PWA</a></p>';
		echo '<p>Sur Android (Chrome): ouvre la PWA → menu ⋮ → <b>Ajouter à l’écran d’accueil</b>. Ensuite, depuis une page/app: <b>Partager</b> → <b>WPA Agent</b>.</p>';

		echo '<hr/>';
		echo '<h2>Réglages IA (génération de draft WordPress)</h2>';
		echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
		wp_nonce_field('wpagent_save_settings');
		echo '<input type="hidden" name="action" value="wpagent_save_settings"/>';

		echo '<table class="form-table" role="presentation"><tbody>';
		echo '<tr><th scope="row"><label for="provider">Provider</label></th><td>';
		echo '<select name="provider" id="provider">';
		echo '<option value="openrouter"' . selected($provider, 'openrouter', false) . '>OpenRouter</option>';
		echo '<option value="gemini"' . selected($provider, 'gemini', false) . '>Gemini</option>';
		echo '</select>';
		echo '</td></tr>';

		echo '<tr><th scope="row"><label for="openrouter_api_key">OpenRouter API Key</label></th><td>';
		echo '<input name="openrouter_api_key" id="openrouter_api_key" type="password" class="regular-text" value="' . esc_attr($openrouter_key) . '" autocomplete="off"/>';
		echo '<p class="description">Utilisé si provider=OpenRouter.</p>';
		echo '</td></tr>';
		echo '<tr><th scope="row"><label for="openrouter_model">OpenRouter model</label></th><td>';
		echo '<input name="openrouter_model" id="openrouter_model" type="text" class="regular-text" value="' . esc_attr($openrouter_model) . '"/>';
		echo '</td></tr>';

		echo '<tr><th scope="row"><label for="gemini_api_key">Gemini API Key</label></th><td>';
		echo '<input name="gemini_api_key" id="gemini_api_key" type="password" class="regular-text" value="' . esc_attr($gemini_key) . '" autocomplete="off"/>';
		echo '<p class="description">Utilisé si provider=Gemini.</p>';
		echo '</td></tr>';
		echo '<tr><th scope="row"><label for="gemini_model">Gemini model</label></th><td>';
		echo '<input name="gemini_model" id="gemini_model" type="text" class="regular-text" value="' . esc_attr($gemini_model) . '"/>';
		echo '</td></tr>';

		echo '<tr><th scope="row"><label for="system_prompt">System prompt</label></th><td>';
		echo '<textarea name="system_prompt" id="system_prompt" class="large-text" rows="4">' . esc_textarea($system_prompt) . '</textarea>';
		echo '</td></tr>';
		echo '</tbody></table>';
		submit_button('Enregistrer');
		echo '</form>';

		echo '<hr/>';
		echo '<h2>Inbox → Générer un draft</h2>';
		echo '<p>Ajoute des sujets (via PWA / capture) puis clique “Générer un draft”. Le draft est créé en <code>post</code> (statut <code>draft</code>).</p>';

		$query = new \WP_Query(
			[
				'post_type' => WPAgent_Post_Type::POST_TYPE,
				'post_status' => 'publish',
				'posts_per_page' => 20,
				'orderby' => 'date',
				'order' => 'DESC',
				'no_found_rows' => true,
			]
		);

		if (!$query->have_posts()) {
			echo '<p>Aucun sujet pour le moment.</p>';
		} else {
			echo '<table class="widefat striped"><thead><tr>';
			echo '<th>Sujet</th><th>Statut IA</th><th>Draft</th><th>Action</th>';
			echo '</tr></thead><tbody>';
			foreach ($query->posts as $topic) {
				$topic_id = (int) $topic->ID;
				$status = (string) get_post_meta($topic_id, '_wpagent_ai_status', true);
				$error = (string) get_post_meta($topic_id, '_wpagent_ai_error', true);
				$draft_id = (int) get_post_meta($topic_id, '_wpagent_draft_post_id', true);
				$draft_link = $draft_id > 0 ? get_edit_post_link($draft_id, 'url') : '';

				echo '<tr>';
				echo '<td><strong>' . esc_html(get_the_title($topic)) . '</strong><br/><span class="description">' . esc_html(get_the_date('', $topic)) . '</span></td>';
				echo '<td>' . esc_html($status !== '' ? $status : '—') . ($error !== '' ? '<br/><span style="color:#b32d2e">' . esc_html($error) . '</span>' : '') . '</td>';
				echo '<td>' . ($draft_link ? '<a href="' . esc_url($draft_link) . '">Éditer draft #' . (int) $draft_id . '</a>' : '—') . '</td>';
				echo '<td>';
				echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="margin:0">';
				wp_nonce_field('wpagent_generate_draft');
				echo '<input type="hidden" name="action" value="wpagent_generate_draft"/>';
				echo '<input type="hidden" name="topic_id" value="' . (int) $topic_id . '"/>';
				submit_button('Générer un draft', 'primary', 'submit', false);
				echo '</form>';
				echo '</td>';
				echo '</tr>';
			}
			echo '</tbody></table>';
		}

		echo '<h2>Exemples</h2>';
		echo '<p>GET (simple):</p>';
		echo '<pre style="background:#fff;padding:12px;border:1px solid #dcdcde;max-width:100%;overflow:auto;">' .
			esc_html($inbox_url . '?token=' . $token . '&text=' . rawurlencode('Idée d’article…')) .
			'</pre>';
		echo '<p>POST (recommandé): token + text (+ url/source_title).</p>';

		echo '</div>';
	}
}
