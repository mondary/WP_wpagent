<?php

if (!defined('ABSPATH')) {
	exit;
}

final class WPAgent_AI {
	public static function init(): void {
		// Future: cron jobs, background processing, etc.
	}

	public static function generate_draft_from_topic(int $topic_id): int|\WP_Error {
		$post = get_post($topic_id);
		if (!$post || $post->post_type !== WPAgent_Post_Type::POST_TYPE) {
			return new \WP_Error('wpagent_not_found', 'Sujet introuvable.', ['status' => 404]);
		}

		$existing_draft_id = (int) get_post_meta($topic_id, '_wpagent_draft_post_id', true);
		if ($existing_draft_id > 0 && get_post($existing_draft_id)) {
			return $existing_draft_id;
		}

		update_post_meta($topic_id, '_wpagent_ai_status', 'running');
		delete_post_meta($topic_id, '_wpagent_ai_error');

		$source_url = (string) get_post_meta($topic_id, '_wpagent_source_url', true);
		$source_title = (string) get_post_meta($topic_id, '_wpagent_source_title', true);

		$prompt = self::build_prompt((string) $post->post_content, $source_url, $source_title);
		$result = self::call_model($prompt);

		if (is_wp_error($result)) {
			update_post_meta($topic_id, '_wpagent_ai_status', 'error');
			update_post_meta($topic_id, '_wpagent_ai_error', $result->get_error_message());
			return $result;
		}

		$draft_id = wp_insert_post(
			[
				'post_type' => 'post',
				'post_status' => 'draft',
				'post_title' => (string) get_the_title($post),
				'post_content' => $result['content'],
			],
			true
		);

		if (is_wp_error($draft_id)) {
			update_post_meta($topic_id, '_wpagent_ai_status', 'error');
			update_post_meta($topic_id, '_wpagent_ai_error', $draft_id->get_error_message());
			return $draft_id;
		}

		$draft_id = (int) $draft_id;
		update_post_meta($topic_id, '_wpagent_draft_post_id', $draft_id);
		update_post_meta($topic_id, '_wpagent_ai_status', 'done');

		return $draft_id;
	}

	private static function build_prompt(string $topic_html, string $source_url, string $source_title): string {
		$system = WPAgent_Settings::get_system_prompt();

		$topic_text = trim(wp_strip_all_tags($topic_html));
		$topic_text = preg_replace('/\s+/', ' ', $topic_text ?? '');

		$context = "Idée brute:\n" . $topic_text . "\n";
		if ($source_url !== '') {
			$context .= "\nSource URL: " . $source_url . "\n";
		}
		if ($source_title !== '') {
			$context .= "Source titre: " . $source_title . "\n";
		}

		return $system . "\n\n" .
			"Contraintes:\n" .
			"- Réponds en français.\n" .
			"- Structure en Markdown (titres, listes) adapté à un brouillon WordPress.\n" .
			"- Ajoute un plan clair, puis le contenu.\n\n" .
			$context;
	}

	/**
	 * @return array{content:string}|\WP_Error
	 */
	private static function call_model(string $prompt): array|\WP_Error {
		$provider = WPAgent_Settings::get_provider();
		if ($provider === 'gemini') {
			return self::call_gemini($prompt);
		}
		return self::call_openrouter($prompt);
	}

	/**
	 * @return array{content:string}|\WP_Error
	 */
	private static function call_openrouter(string $prompt): array|\WP_Error {
		$api_key = (string) get_option(WPAgent_Settings::OPTION_OPENROUTER_API_KEY, '');
		$api_key = trim($api_key);
		if ($api_key === '') {
			return new \WP_Error('wpagent_ai_missing_key', 'Clé API OpenRouter manquante (admin WPA Agent).');
		}

		$model = WPAgent_Settings::get_openrouter_model();

		$resp = wp_remote_post(
			'https://openrouter.ai/api/v1/chat/completions',
			[
				'timeout' => 60,
				'headers' => [
					'Authorization' => 'Bearer ' . $api_key,
					'Content-Type' => 'application/json',
				],
				'body' => wp_json_encode(
					[
						'model' => $model,
						'messages' => [
							['role' => 'user', 'content' => $prompt],
						],
					]
				),
			]
		);

		if (is_wp_error($resp)) {
			return $resp;
		}

		$code = (int) wp_remote_retrieve_response_code($resp);
		$body = (string) wp_remote_retrieve_body($resp);
		$data = json_decode($body, true);

		if ($code < 200 || $code >= 300) {
			$message = is_array($data) && isset($data['error']['message']) ? (string) $data['error']['message'] : $body;
			return new \WP_Error('wpagent_ai_http', 'OpenRouter: ' . $message);
		}

		$content = '';
		if (is_array($data) && isset($data['choices'][0]['message']['content'])) {
			$content = (string) $data['choices'][0]['message']['content'];
		}
		$content = trim($content);
		if ($content === '') {
			return new \WP_Error('wpagent_ai_empty', 'OpenRouter: réponse vide.');
		}

		return ['content' => $content];
	}

	/**
	 * Gemini (API v1beta) - implémentation simple côté texte.
	 * @return array{content:string}|\WP_Error
	 */
	private static function call_gemini(string $prompt): array|\WP_Error {
		$api_key = (string) get_option(WPAgent_Settings::OPTION_GEMINI_API_KEY, '');
		$api_key = trim($api_key);
		if ($api_key === '') {
			return new \WP_Error('wpagent_ai_missing_key', 'Clé API Gemini manquante (admin WPA Agent).');
		}

		$model = WPAgent_Settings::get_gemini_model();
		$url = 'https://generativelanguage.googleapis.com/v1beta/models/' . rawurlencode($model) . ':generateContent?key=' . rawurlencode($api_key);

		$resp = wp_remote_post(
			$url,
			[
				'timeout' => 60,
				'headers' => [
					'Content-Type' => 'application/json',
				],
				'body' => wp_json_encode(
					[
						'contents' => [
							[
								'role' => 'user',
								'parts' => [
									['text' => $prompt],
								],
							],
						],
					]
				),
			]
		);

		if (is_wp_error($resp)) {
			return $resp;
		}

		$code = (int) wp_remote_retrieve_response_code($resp);
		$body = (string) wp_remote_retrieve_body($resp);
		$data = json_decode($body, true);

		if ($code < 200 || $code >= 300) {
			$message = is_array($data) && isset($data['error']['message']) ? (string) $data['error']['message'] : $body;
			return new \WP_Error('wpagent_ai_http', 'Gemini: ' . $message);
		}

		$text = '';
		if (is_array($data) && isset($data['candidates'][0]['content']['parts'][0]['text'])) {
			$text = (string) $data['candidates'][0]['content']['parts'][0]['text'];
		}
		$text = trim($text);
		if ($text === '') {
			return new \WP_Error('wpagent_ai_empty', 'Gemini: réponse vide.');
		}

		return ['content' => $text];
	}
}

