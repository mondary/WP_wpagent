<?php

if (!defined('ABSPATH')) {
	exit;
}

final class WPAgent_REST {
	public static function init(): void {
		add_action('rest_api_init', [self::class, 'register_routes']);
	}

	public static function register_routes(): void {
		register_rest_route(
			'wpagent/v1',
			'/inbox',
			[
				[
					'methods' => ['GET', 'POST'],
					'callback' => [self::class, 'handle_inbox'],
					'permission_callback' => '__return_true',
					'args' => [
						'token' => ['required' => true, 'type' => 'string'],
						'text' => ['required' => false, 'type' => 'string'],
						'url' => ['required' => false, 'type' => 'string'],
						'source_title' => ['required' => false, 'type' => 'string'],
					],
				],
			]
		);

		register_rest_route(
			'wpagent/v1',
			'/topics',
			[
				[
					'methods' => ['GET'],
					'callback' => [self::class, 'handle_topics'],
					'permission_callback' => '__return_true',
					'args' => [
						'token' => ['required' => true, 'type' => 'string'],
						'limit' => ['required' => false, 'type' => 'integer', 'default' => 50],
					],
				],
			]
		);

		register_rest_route(
			'wpagent/v1',
			'/capture',
			[
				[
					'methods' => ['GET'],
					'callback' => [self::class, 'handle_capture_page'],
					'permission_callback' => '__return_true',
					'args' => [
						'token' => ['required' => true, 'type' => 'string'],
					],
				],
			]
		);

		register_rest_route(
			'wpagent/v1',
			'/pwa/app',
			[
				[
					'methods' => ['GET'],
					'callback' => [self::class, 'handle_pwa_app'],
					'permission_callback' => '__return_true',
				],
			]
		);

		register_rest_route(
			'wpagent/v1',
			'/pwa/share',
			[
				[
					'methods' => ['POST'],
					'callback' => [self::class, 'handle_pwa_share_target'],
					'permission_callback' => '__return_true',
				],
			]
		);

		register_rest_route(
			'wpagent/v1',
			'/pwa/manifest',
			[
				[
					'methods' => ['GET'],
					'callback' => [self::class, 'handle_pwa_manifest'],
					'permission_callback' => '__return_true',
				],
			]
		);

		register_rest_route(
			'wpagent/v1',
			'/pwa/sw',
			[
				[
					'methods' => ['GET'],
					'callback' => [self::class, 'handle_pwa_sw'],
					'permission_callback' => '__return_true',
				],
			]
		);

		register_rest_route(
			'wpagent/v1',
			'/pwa/icon',
			[
				[
					'methods' => ['GET'],
					'callback' => [self::class, 'handle_pwa_icon'],
					'permission_callback' => '__return_true',
				],
			]
		);
	}

	private static function require_token(\WP_REST_Request $request): true|\WP_Error {
		$provided = (string) $request->get_param('token');
		$expected = WPAgent_Settings::get_token();
		if ($provided === '' || !hash_equals($expected, $provided)) {
			return new \WP_Error('wpagent_forbidden', 'Token invalide.', ['status' => 403]);
		}
		return true;
	}

	public static function handle_inbox(\WP_REST_Request $request): \WP_REST_Response|\WP_Error {
		$ok = self::require_token($request);
		if (is_wp_error($ok)) {
			return $ok;
		}

		$text = (string) ($request->get_param('text') ?? '');
		$url = (string) ($request->get_param('url') ?? '');
		$source_title = (string) ($request->get_param('source_title') ?? '');

		// Friendly fallback: allow sharing a URL only, as text.
		if ($text === '' && $url !== '') {
			$text = $url;
		}

		$post_id = WPAgent_Post_Type::create_topic(
			[
				'text' => $text,
				'url' => $url,
				'source_title' => $source_title,
			]
		);

		if (is_wp_error($post_id)) {
			return $post_id;
		}

		return new \WP_REST_Response(
			[
				'ok' => true,
				'id' => (int) $post_id,
			],
			201
		);
	}

	public static function handle_topics(\WP_REST_Request $request): \WP_REST_Response|\WP_Error {
		$ok = self::require_token($request);
		if (is_wp_error($ok)) {
			return $ok;
		}

		$limit = (int) ($request->get_param('limit') ?? 50);
		$limit = max(1, min(200, $limit));

		$query = new \WP_Query(
			[
				'post_type' => WPAgent_Post_Type::POST_TYPE,
				'post_status' => 'publish',
				'posts_per_page' => $limit,
				'orderby' => 'date',
				'order' => 'DESC',
				'no_found_rows' => true,
			]
		);

		$items = [];
		foreach ($query->posts as $post) {
			$items[] = [
				'id' => (int) $post->ID,
				'title' => (string) get_the_title($post),
				'content' => (string) $post->post_content,
				'created_at' => (string) get_the_date('c', $post),
				'source_url' => (string) get_post_meta($post->ID, '_wpagent_source_url', true),
				'source_title' => (string) get_post_meta($post->ID, '_wpagent_source_title', true),
			];
		}

		return new \WP_REST_Response(['ok' => true, 'items' => $items], 200);
	}

	public static function handle_capture_page(\WP_REST_Request $request): \WP_REST_Response|\WP_Error {
		$ok = self::require_token($request);
		if (is_wp_error($ok)) {
			return $ok;
		}

		$token = (string) $request->get_param('token');
		$action_url = esc_url(site_url('/wp-json/wpagent/v1/inbox'));
		$token_esc = esc_attr($token);

		$html = '<!doctype html><html><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width, initial-scale=1"/>';
		$html .= '<title>WPA Agent — Capture</title>';
		$html .= '<style>body{font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;margin:16px;max-width:720px}textarea,input{width:100%;font-size:16px;padding:10px;margin:8px 0}button{font-size:16px;padding:10px 14px}small{color:#555}</style>';
		$html .= '</head><body>';
		$html .= '<h1>WPA Agent — Capture</h1>';
		$html .= '<form method="post" action="' . $action_url . '">';
		$html .= '<input type="hidden" name="token" value="' . $token_esc . '"/>';
		$html .= '<label>Texte / idée</label><textarea name="text" rows="6" placeholder="Colle ici ton idée…"></textarea>';
		$html .= '<label>URL (optionnel)</label><input name="url" type="url" placeholder="https://…"/>';
		$html .= '<label>Titre source (optionnel)</label><input name="source_title" type="text" placeholder="Titre de l’article / vidéo…"/>';
		$html .= '<button type="submit">Ajouter à la liste</button>';
		$html .= '</form>';
		$html .= '<p><small>Astuce iOS Raccourcis: action “Obtenir le contenu de l’URL” en POST vers <code>' . esc_html($action_url) . '</code> avec les champs token/text/url.</small></p>';
		$html .= '</body></html>';

		$response = new \WP_REST_Response($html, 200);
		$response->header('Content-Type', 'text/html; charset=utf-8');
		return $response;
	}

	public static function handle_pwa_manifest(\WP_REST_Request $request): \WP_REST_Response {
		$app_url = site_url('/wp-json/wpagent/v1/pwa/app');
		$share_action = site_url('/wp-json/wpagent/v1/pwa/share');
		$sw_url = site_url('/wp-json/wpagent/v1/pwa/sw');
		$icon_url = site_url('/wp-json/wpagent/v1/pwa/icon');

		$manifest = [
			'name' => 'WPA Agent',
			'short_name' => 'WPA Agent',
			'start_url' => $app_url,
			'scope' => site_url('/'),
			'display' => 'standalone',
			'background_color' => '#0b1220',
			'theme_color' => '#0b1220',
			'icons' => [
				[
					'src' => $icon_url,
					'sizes' => '512x512',
					'type' => 'image/svg+xml',
					'purpose' => 'any maskable',
				],
			],
			'share_target' => [
				'action' => $share_action,
				'method' => 'POST',
				'enctype' => 'application/x-www-form-urlencoded',
				'params' => [
					'title' => 'title',
					'text' => 'text',
					'url' => 'url',
				],
			],
		];

		$response = new \WP_REST_Response(wp_json_encode($manifest), 200);
		$response->header('Content-Type', 'application/manifest+json; charset=utf-8');
		$response->header('Service-Worker-Allowed', esc_url_raw(site_url('/')));
		$response->header('Cache-Control', 'no-store');
		$response->header('X-WPA-SW', esc_url_raw($sw_url));
		return $response;
	}

	public static function handle_pwa_sw(\WP_REST_Request $request): \WP_REST_Response {
		$manifest_url = site_url('/wp-json/wpagent/v1/pwa/manifest');
		$app_url = site_url('/wp-json/wpagent/v1/pwa/app');

		$js = "(function(){\n" .
			"const CACHE='wpagent-pwa-v1';\n" .
			"self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(['" . esc_js($app_url) . "','" . esc_js($manifest_url) . "'])));self.skipWaiting();});\n" .
			"self.addEventListener('activate',e=>{e.waitUntil(self.clients.claim());});\n" .
			"self.addEventListener('fetch',e=>{const url=new URL(e.request.url);if(e.request.method!=='GET')return; if(url.pathname.includes('/wp-json/wpagent/v1/pwa/')){e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request).then(fr=>{const c=fr.clone();caches.open(CACHE).then(cache=>cache.put(e.request,c));return fr;})));}});\n" .
			"})();\n";

		$response = new \WP_REST_Response($js, 200);
		$response->header('Content-Type', 'application/javascript; charset=utf-8');
		$response->header('Cache-Control', 'no-store');
		return $response;
	}

	public static function handle_pwa_icon(\WP_REST_Request $request): \WP_REST_Response {
		$svg = '<svg xmlns="http://www.w3.org/2000/svg" width="512" height="512" viewBox="0 0 512 512">' .
			'<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">' .
			'<stop offset="0" stop-color="#7c3aed"/><stop offset="1" stop-color="#22c55e"/>' .
			'</linearGradient></defs>' .
			'<rect width="512" height="512" rx="112" fill="#0b1220"/>' .
			'<circle cx="256" cy="256" r="162" fill="url(#g)" opacity="0.9"/>' .
			'<path d="M170 320l32-160h56l22 98 22-98h56l32 160h-52l-14-84-20 84h-48l-20-84-14 84z" fill="#0b1220"/>' .
			'</svg>';

		$response = new \WP_REST_Response($svg, 200);
		$response->header('Content-Type', 'image/svg+xml; charset=utf-8');
		$response->header('Cache-Control', 'public, max-age=86400');
		return $response;
	}

	public static function handle_pwa_app(\WP_REST_Request $request): \WP_REST_Response {
		$manifest = esc_url(site_url('/wp-json/wpagent/v1/pwa/manifest'));
		$sw = esc_url(site_url('/wp-json/wpagent/v1/pwa/sw'));
		$inbox = esc_url(site_url('/wp-json/wpagent/v1/inbox'));
		$topics = esc_url(site_url('/wp-json/wpagent/v1/topics'));

		$html = '<!doctype html><html><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width, initial-scale=1"/>';
		$html .= '<title>WPA Agent</title>';
		$html .= '<link rel="manifest" href="' . $manifest . '"/>';
		$html .= '<meta name="theme-color" content="#0b1220"/>';
		$html .= '<style>
			:root{--bg:#0b1220;--card:#111a2e;--text:#e8eefc;--muted:#9fb0d0;--acc:#7c3aed;--ok:#22c55e;--err:#ef4444}
			body{margin:0;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;background:linear-gradient(180deg,#070b14,#0b1220);color:var(--text)}
			.wrap{max-width:860px;margin:0 auto;padding:18px}
			.card{background:rgba(17,26,46,.92);border:1px solid rgba(255,255,255,.08);border-radius:14px;padding:14px;margin:12px 0;box-shadow:0 10px 30px rgba(0,0,0,.35)}
			h1{font-size:20px;margin:8px 0 0}
			p{color:var(--muted);margin:6px 0 0}
			label{display:block;font-size:12px;color:var(--muted);margin-top:10px}
			input,textarea,select{width:100%;padding:12px 12px;border-radius:12px;border:1px solid rgba(255,255,255,.12);background:rgba(7,11,20,.65);color:var(--text);font-size:16px;box-sizing:border-box}
			textarea{min-height:120px;resize:vertical}
			.row{display:grid;grid-template-columns:1fr;gap:10px}
			.btn{display:inline-flex;align-items:center;justify-content:center;border:0;border-radius:12px;padding:12px 14px;background:var(--acc);color:#fff;font-weight:650;font-size:16px}
			.btn.secondary{background:rgba(255,255,255,.12)}
			.small{font-size:12px;color:var(--muted)}
			.status{margin-top:10px;font-size:13px}
			.status.ok{color:var(--ok)} .status.err{color:var(--err)}
			.items{margin-top:8px}
			.item{padding:10px;border-radius:12px;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.08);margin:8px 0}
			.item b{display:block;margin-bottom:4px}
			code{background:rgba(0,0,0,.3);padding:2px 6px;border-radius:8px}
		</style>';
		$html .= '</head><body><div class="wrap">';
		$html .= '<div class="card"><h1>WPA Agent</h1><p>Inbox de sujets → génération IA → draft WordPress → publication.</p></div>';
		$html .= '<div class="card"><h2 style="margin:0;font-size:16px">Connexion</h2><p class="small">Saisis ton token une fois (stocké localement sur ton téléphone).</p>';
		$html .= '<label>Token</label><input id="token" placeholder="colle le token"/>';
		$html .= '<div style="display:flex;gap:10px;margin-top:10px;flex-wrap:wrap">';
		$html .= '<button class="btn secondary" id="saveToken" type="button">Enregistrer</button>';
		$html .= '<button class="btn secondary" id="clearToken" type="button">Effacer</button>';
		$html .= '</div><div id="tokenStatus" class="status"></div></div>';
		$html .= '<div class="card"><h2 style="margin:0;font-size:16px">Ajouter un sujet</h2>';
		$html .= '<label>Texte / idée</label><textarea id="text" placeholder="Écris ton idée…"></textarea>';
		$html .= '<label>URL (optionnel)</label><input id="url" type="url" placeholder="https://…"/>';
		$html .= '<label>Titre source (optionnel)</label><input id="source_title" type="text" placeholder="Titre…"/>';
		$html .= '<div style="display:flex;gap:10px;margin-top:10px;flex-wrap:wrap">';
		$html .= '<button class="btn" id="send" type="button">Ajouter à l’inbox</button>';
		$html .= '<button class="btn secondary" id="refresh" type="button">Rafraîchir la liste</button>';
		$html .= '</div><div id="sendStatus" class="status"></div>';
		$html .= '<div class="items" id="items"></div></div>';
		$html .= '<div class="card"><p class="small">Install Android: ouvre cette page dans Chrome → menu ⋮ → “Ajouter à l’écran d’accueil”. Ensuite “Partager” → “WPA Agent”.</p>';
		$html .= '<p class="small">API: <code>' . esc_html($inbox) . '</code> / <code>' . esc_html($topics) . '</code></p></div>';

		$html .= '<script>
			const inboxUrl=' . json_encode($inbox) . ';
			const topicsUrl=' . json_encode($topics) . ';
			const swUrl=' . json_encode($sw) . ';
			const $=(id)=>document.getElementById(id);
			function getToken(){return localStorage.getItem("wpagent_token")||"";}
			function setToken(t){localStorage.setItem("wpagent_token",t);}
			function clearToken(){localStorage.removeItem("wpagent_token");}
			function setStatus(el,msg,ok){el.textContent=msg;el.className="status "+(ok?"ok":"err");}
			function esc(s){return (s||"").replace(/[&<>]/g,c=>({ "&":"&amp;","<":"&lt;",">":"&gt;" }[c]));}
			async function addTopic(payload){
				const token=getToken();
				if(!token){throw new Error("Token manquant");}
				const form=new URLSearchParams();
				form.set("token",token);
				for(const k of ["text","url","source_title"]){ if(payload[k]) form.set(k,payload[k]); }
				const res=await fetch(inboxUrl,{method:"POST",headers:{ "Content-Type":"application/x-www-form-urlencoded" },body:form.toString()});
				const txt=await res.text();
				let data; try{ data=JSON.parse(txt); }catch(e){ throw new Error("Réponse invalide"); }
				if(!res.ok){ throw new Error(data.message||"Erreur"); }
				return data;
			}
			async function refresh(){
				const token=getToken();
				if(!token){ throw new Error("Token manquant");}
				const res=await fetch(topicsUrl+"?token="+encodeURIComponent(token)+"&limit=50",{method:"GET"});
				const txt=await res.text();
				let data; try{ data=JSON.parse(txt);}catch(e){ throw new Error("Réponse invalide"); }
				if(!res.ok){ throw new Error(data.message||"Erreur"); }
				const items=data.items||[];
				const root=$("items"); root.innerHTML="";
				if(items.length===0){ root.innerHTML="<p class=\\"small\\">Aucun sujet pour le moment.</p>"; return; }
				for(const it of items){
					const div=document.createElement("div"); div.className="item";
					div.innerHTML="<b>"+esc(it.title||("Sujet #"+it.id))+"</b><div class=\\"small\\">"+esc((it.content||"").slice(0,180))+"</div>";
					root.appendChild(div);
				}
			}
			$("token").value=getToken();
			$("saveToken").addEventListener("click",()=>{ setToken($("token").value.trim()); setStatus($("tokenStatus"),"Token enregistré.",true); });
			$("clearToken").addEventListener("click",()=>{ clearToken(); $("token").value=""; setStatus($("tokenStatus"),"Token effacé.",true); });
			$("send").addEventListener("click",async()=>{
				try{
					setStatus($("sendStatus"),"Envoi…",true);
					await addTopic({ text:$("text").value.trim(), url:$("url").value.trim(), source_title:$("source_title").value.trim() });
					$("text").value=""; $("url").value=""; $("source_title").value="";
					setStatus($("sendStatus"),"Ajouté à l’inbox.",true);
					await refresh();
				}catch(e){ setStatus($("sendStatus"),e.message||"Erreur",false); }
			});
			$("refresh").addEventListener("click",async()=>{ try{ await refresh(); setStatus($("sendStatus"),"Liste à jour.",true);}catch(e){ setStatus($("sendStatus"),e.message||"Erreur",false);} });
			if("serviceWorker" in navigator){
				navigator.serviceWorker.register(swUrl).catch(()=>{});
			}

			async function consumeShareIfAny(){
				let raw="";
				try{ raw=localStorage.getItem("wpagent_share_payload")||""; }catch(e){}
				if(!raw) return;
				let data=null;
				try{ data=JSON.parse(raw); }catch(e){}
				if(!data) return;

				const token=getToken();
				const title=(data.title||"").trim();
				const text=(data.text||"").trim();
				const url=(data.url||"").trim();

				// Build a reasonable text when user shares a URL/title.
				let idea=text || title || "";
				if(url && !idea) idea=url;
				if(url && idea && !idea.includes(url)) idea = idea + "\\n" + url;

				$("text").value = idea;
				$("url").value = url;
				$("source_title").value = title;

				if(!token){
					setStatus($("sendStatus"),"Contenu partagé détecté. Ajoute ton token puis clique “Ajouter à l’inbox”.",false);
					return;
				}

				try{
					setStatus($("sendStatus"),"Ajout automatique (partage)…",true);
					await addTopic({ text:idea, url:url, source_title:title });
					$("text").value=""; $("url").value=""; $("source_title").value="";
					try{ localStorage.removeItem("wpagent_share_payload"); }catch(e){}
					setStatus($("sendStatus"),"Ajouté à l’inbox.",true);
					await refresh();
				}catch(e){
					setStatus($("sendStatus"),e.message||"Erreur",false);
				}
			}

			// First load
			refresh().catch(()=>{});
			consumeShareIfAny().catch(()=>{});
		</script>';
		$html .= '</div></body></html>';

		$response = new \WP_REST_Response($html, 200);
		$response->header('Content-Type', 'text/html; charset=utf-8');
		$response->header('Cache-Control', 'no-store');
		return $response;
	}

	public static function handle_pwa_share_target(\WP_REST_Request $request): \WP_REST_Response {
		$title = (string) $request->get_param('title');
		$text = (string) $request->get_param('text');
		$url = (string) $request->get_param('url');

		$app_url = esc_url(site_url('/wp-json/wpagent/v1/pwa/app'));

		$payload = [
			'title' => $title,
			'text' => $text,
			'url' => $url,
		];

		$html = '<!doctype html><html><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width, initial-scale=1"/>';
		$html .= '<title>WPA Agent — Share</title></head><body>';
		$html .= '<script>
			(function(){
				const data=' . wp_json_encode($payload) . ';
				try{
					localStorage.setItem("wpagent_share_payload", JSON.stringify(data));
				}catch(e){}
				location.replace(' . json_encode($app_url . '#share') . ');
			})();
		</script>';
		$html .= '</body></html>';

		$response = new \WP_REST_Response($html, 200);
		$response->header('Content-Type', 'text/html; charset=utf-8');
		$response->header('Cache-Control', 'no-store');
		return $response;
	}
}
