<?php

if (!defined('ABSPATH')) {
	exit;
}

final class WPAgent_Settings {
	public const OPTION_TOKEN = 'wpagent_token';
	public const OPTION_PROVIDER = 'wpagent_ai_provider';
	public const OPTION_OPENROUTER_API_KEY = 'wpagent_openrouter_api_key';
	public const OPTION_OPENROUTER_MODEL = 'wpagent_openrouter_model';
	public const OPTION_GEMINI_API_KEY = 'wpagent_gemini_api_key';
	public const OPTION_GEMINI_MODEL = 'wpagent_gemini_model';
	public const OPTION_SYSTEM_PROMPT = 'wpagent_system_prompt';

	public static function init(): void {
		// Reserved for future hooks.
	}

	public static function generate_token(): string {
		$token = wp_generate_password(32, false, false);
		return strtolower($token);
	}

	public static function get_token(): string {
		$token = (string) get_option(self::OPTION_TOKEN, '');
		if ($token === '') {
			$token = self::generate_token();
			update_option(self::OPTION_TOKEN, $token, false);
		}
		return $token;
	}

	public static function regenerate_token(): string {
		$token = self::generate_token();
		update_option(self::OPTION_TOKEN, $token, false);
		return $token;
	}

	public static function get_provider(): string {
		$provider = (string) get_option(self::OPTION_PROVIDER, 'openrouter');
		$provider = strtolower(trim($provider));
		if (!in_array($provider, ['openrouter', 'gemini'], true)) {
			$provider = 'openrouter';
		}
		return $provider;
	}

	public static function get_openrouter_model(): string {
		$model = (string) get_option(self::OPTION_OPENROUTER_MODEL, 'openai/gpt-4o-mini');
		$model = trim($model);
		return $model !== '' ? $model : 'openai/gpt-4o-mini';
	}

	public static function get_gemini_model(): string {
		$model = (string) get_option(self::OPTION_GEMINI_MODEL, 'gemini-1.5-flash');
		$model = trim($model);
		return $model !== '' ? $model : 'gemini-1.5-flash';
	}

	public static function get_system_prompt(): string {
		$prompt = (string) get_option(
			self::OPTION_SYSTEM_PROMPT,
			"Tu es un assistant de rédaction. Transforme une idée brute en brouillon d'article WordPress clair, structuré, et prêt à relire."
		);
		return trim($prompt);
	}
}
